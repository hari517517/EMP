﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emp_DAL;
using Emp_Exception;
using Emp_Entity;


namespace Emp_BAL
{
    public class Employee_BAL
    {
        public static List<Employee_Enti> emps = new List<Employee_Enti>();
        private static bool ValidationEmployee(Employee_Enti employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            //validating data 
            if(employee.Emp_Id<=10000)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Employee ID");
            }
            if(employee.Emp_Name==string.Empty)
            {
                validEmployee = true;
                sb.Append(Environment.NewLine + "please enter the employee name");

            }
            if(employee.Emp_Salary<=1000000)
            {
                validEmployee = true;
                sb.Append(Environment.NewLine + "salary should be less than 1000000");
            }
            if(employee.Emp_DOJ<=DateTime.Now)
            {
                validEmployee = true;
                sb.Append(Environment.NewLine + "please provide valid date before today date");
            }
            if(validEmployee==false)
            {
                throw new EmployeeNotFoundException(sb.ToString());

            }
            return validEmployee;
     
        }
        //adding employee information
        public static bool AddEmployeeBAL(Employee_Enti BalEmployee)
        {
            bool EmployeeAdded = false;
            try
            {
                if(ValidationEmployee(BalEmployee))
                {
                    Employee_DAL employee_DAL = new Employee_DAL();
                    EmployeeAdded = employee_DAL.AddEmployeeDAL(BalEmployee);
                }
            }
        
            catch (EmployeeNotFoundException ex)
            {

                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return EmployeeAdded;
        }
        //diplaying employee Details
        public static Employee_Enti DisplayEmployeeBAL(int displayemployeeID)
        {
            Employee_Enti displayEmployee = null;
            try
            {
                Employee_DAL employee_DAL = new Employee_DAL();
                displayEmployee=employee_DAL.DisplayEmployeeDAL(displayemployeeID);

            }
            catch (EmployeeNotFoundException ex)
            {
                throw ex;
              
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return displayEmployee;
        }
        public static void SerializaData()
        {
            Employee_DAL.SerializaData();
        }
    }
}
